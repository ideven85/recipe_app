document.querySelectorAll('.btn_js').forEach(function(elem) {
    elem.addEventListener('click', function(event) {
        event.stopPropagation();
        elem.parentNode.classList.toggle('show');
    });
});

document.addEventListener('click', function(event) {
    if (!event.target.closest('[data-attr-content]')) {
        document.querySelectorAll('.show').forEach(function(elem) {
            elem.classList.remove('show');
        });
    }
});