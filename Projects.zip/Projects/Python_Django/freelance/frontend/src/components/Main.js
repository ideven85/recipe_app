import React, { useState, useEffect, useRef } from 'react';
import io from 'socket.io-client';
import './Main.css';

const socket = io('http://localhost:5000/');

const Main = () => {
  const [formId, setFormId] = useState('mainForm');
  const [taskId, setTaskId] = useState(null);
  const [uploadController, setUploadController] = useState(null);
  const [videoLinks, setVideoLinks] = useState([]);
  const [videoFileNames, setVideoFileNames] = useState('');
  const [googleSheetLink, setGoogleSheetLink] = useState('');
  const [topBoxColor, setTopBoxColor] = useState('#485aff'); // Default color in HEX format
  const [textColor, setTextColor] = useState('#ffffff'); // Default text color in HEX format
  const [outputVideosFolder, setOutputVideosFolder] = useState(''); // New state to track the output folder

  const videoInputRef = useRef(null);

  useEffect(() => {
    let logInterval = null;

    socket.on('connect', () => {
      console.log('WebSocket connected');
    });

    socket.on('disconnect', () => {
      console.log('WebSocket disconnected');
    });

    socket.on('video_link', (data) => {
      if (data.task_id === taskId) {
        console.log('Received video link:', data.video_link); // Log the link
        setVideoLinks(prevLinks => [...prevLinks, { name: data.file_name, link: data.video_link }]);
        console.log('Name:', data.file_name); // Log the link
      }
    });

    socket.on('task_complete', (data) => {
      if (data.task_id === taskId) {
        clearInterval(logInterval);
        setFormId('completeScreen');
      }
    });

    socket.on('error', (data) => {
      if (data.task_id === taskId) {
        clearInterval(logInterval);
        alert(`Error: ${data.message}`);
        setFormId('mainForm');
      }
    });

    logInterval = setInterval(() => {
      console.log('Task in progress...');
    }, 500);

    return () => {
      clearInterval(logInterval);
      socket.off('connect');
      socket.off('disconnect');
      socket.off('video_link');
      socket.off('task_complete');
      socket.off('error');
    };
  }, [taskId]);

  useEffect(() => {
    // Reset file input fields and labels whenever the formId changes
    setVideoFileNames('');
    setGoogleSheetLink('');
    if (videoInputRef.current) {
      videoInputRef.current.value = null;
    }
  }, [formId]);

  const truncateFileName = (fileName, maxLength = 30) => {
    if (fileName.length <= maxLength) return fileName;
    return fileName.substring(0, maxLength - 3) + '...';
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const formData = new FormData(event.target);
    const taskId = `task-${Math.random().toString(36).substr(2, 9)}`;
    setTaskId(taskId);
    formData.append('task_id', taskId);

    // Append color customization fields to the formData
    formData.append('top_box_color', topBoxColor);
    formData.append('text_color', textColor);
    formData.append('google_sheet_link', googleSheetLink);

    const controller = new AbortController();
    setUploadController(controller);

    fetch('http://localhost:5000/process', {
      method: 'POST',
      body: formData,
      signal: controller.signal,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.error) {
          alert(data.error);
          setFormId('mainForm');
        } else {
          setOutputVideosFolder(data.output_videos_folder); // Store the output folder path
        }
      })
      .catch((error) => {
        if (error.name === 'AbortError') {
          console.log('Upload canceled by user');
        } else {
          alert('An error occurred while processing');
        }
        setFormId('mainForm');
      });

    setFormId('progress');
  };

  const handleCancel = () => {
    if (uploadController) {
      uploadController.abort();
      setUploadController(null);
    }

    if (taskId) {
      fetch('http://localhost:5000/cancel_task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task_id: taskId }),
      })
        .then((response) => response.json())
        .then((data) => {
          alert(data.message);
          setFormId('mainForm');
        })
        .catch((error) => {
          alert('An error occurred while canceling the task');
          setFormId('mainForm');
        });
    }
  };

  const handleGoBack = () => {
    if (formId === 'progress') {
      handleCancel();
    } else {
      setFormId('mainForm');
      setVideoLinks([]);
    }
  };

  const handleDelete = () => {
    fetch('http://localhost:5000/delete_temp_files', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task_id: taskId }),
    })
      .then((response) => response.json())
      .then((data) => {
        alert(data.message);
      })
      .catch((error) => {
        alert('An error occurred while deleting temporary files');
      });
  };

  const handleVideoFilesChange = (event) => {
    const files = Array.from(event.target.files);
    const fileNames = files.length > 1 ? `${files.length} files uploaded` : files.map(file => truncateFileName(file.name)).join(', ');
    setVideoFileNames(fileNames);
  };

  const handleGoogleSheetLinkChange = (event) => {
    setGoogleSheetLink(event.target.value);
  };

  const handleDownloadAll = () => {
    // Trigger the download of the zip file containing all videos
    fetch('http://localhost:5000/download_all', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task_id: taskId, output_videos_folder: outputVideosFolder }),
    })
      .then((response) => response.blob())
      .then((blob) => {
        const url = window.URL.createObjectURL(new Blob([blob]));
        const a = document.createElement('a');
        a.href = url;
        a.download = `videos_${taskId}.zip`;
        document.body.appendChild(a);
        a.click();
        a.remove();
      })
      .catch((error) => {
        alert('An error occurred while downloading the zip file');
      });
  };

  return (
    <div className="wrapper">
      <div class="header inner">
        <div class="container">
          <div class="holder">
            <div class="wrap_holder">
              <div class="logo">
                <a href="/">
                  <img src={"/images/logo-white.svg"} alt="" />
                </a>
              </div>
              <div class="profile_panel">
                <div class="header_text">
                  Credit Remaining: <span>0</span>
                </div>
                <button type="button" class="btn_profile btn_js">
                  <img src={"/images/avatar.svg"} alt="" />
                </button>
                <div class="drop_menu" data-attr-content>
                  <div class="panel">
                    <div class="row">
                      <div class="name">olivia rhye</div>
                    </div>
                    <div class="row">
                      <a href="mailto:olivia@example.com">olivia@example.com</a>
                    </div>
                  </div>
                  <div class="box">
                    <ul class="list">
                      <li class="item">
                        <a href="#">
                          View profile
                        </a>
                      </li>
                      <li class="item">
                        <a href="#">
                          Credit left
                          <span>50</span>
                        </a>
                      </li>
                      <li class="item">
                        <a href="#">
                          Setting
                        </a>
                      </li>
                    </ul>
                    <ul class="list">
                      <li class="item">
                        <a href="#">
                          Log out
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="header_mobile_text">
              Credit Remaining: <span>0</span>
            </div>
          </div>
        </div>
      </div>

      <div className="main">
        <div class="section_form">
          <div class="container_flued">
            <div class="columns">
              <div className="column">
                <div className="card_form">
                  <div class="form_upload">
                    {formId === 'mainForm' && (
                      <form onSubmit={handleSubmit}>
                        <div className='form'>
                          <div class="block">
                            <h1 class="title">Hooks Generation Bot</h1>
                            <div className="row">
                              <h2 className='headline'>Video Files:</h2>
                              <label className='card_upload'>
                                <input type="file" id="video" class="file_upload" name="video" multiple required className="file-input" onChange={handleVideoFilesChange} ref={videoInputRef} />
                                
                                <div class="box">
                                  <img src={"/images/icons/upload.svg"} alt="" />
                                  <span><strong>{videoFileNames || 'Choose files'}</strong></span>
                                </div>
                              </label>
                            </div>

                            <div className="row">
                              <h2 class="headline">Google Sheets Link:</h2>
                              <input
                                type="url"
                                className='input'
                                id="google_sheet_link"
                                name="google_sheet_link"
                                value={googleSheetLink}
                                placeholder='Url Link'
                                onChange={handleGoogleSheetLinkChange}
                                required
                              />
                            </div>

                            <div className="row">
                              <h2 class="headline">Eleven Labs API Key:</h2>
                              <input type="text" className='input' placeholder='Enter Api Key' id="api_key" name="api_key" required />
                            </div>

                            <div className="row">
                              <h2 class="headline">Voice ID:</h2>
                              <input type="text" class="input" placeholder='Enter Voice ID' id="voice_id" name="voice_id" required />
                            </div>

                          </div>

                          <div class="block">
                            <h2 class="title">Customize your hook design</h2>
                            <div className="row">
                              <h2 class="headline">Main box color (Hex):</h2>
                              <div className="input-container">
                                <div
                                  className="square"
                                  style={{
                                    backgroundColor: topBoxColor,
                                  }}
                                ></div>
                                <input
                                  style={
                                    { border: "none", padding: "0rem" }
                                  }
                                  type="text"
                                  id="top_box_color"
                                  name="top_box_color"
                                  value={topBoxColor}
                                  onChange={(e) => setTopBoxColor(e.target.value)}
                                  required
                                />
                              </div>
                            </div>

                            <div className="row">
                              <h2 class="headline">Font color (Hex):</h2>
                              <div className="input-container">
                                <div
                                  className="square"
                                  style={{
                                    backgroundColor: textColor,
                                  }}
                                ></div>
                                <input
                                  className='inp-tec'
                                  style={
                                    { border: "none", padding: "0rem" }
                                  }
                                  type="text"
                                  id="text_color"
                                  name="text_color"
                                  value={textColor}
                                  onChange={(e) => setTextColor(e.target.value)}
                                  required
                                />
                              </div>

                            </div>

                          </div>
                        </div>
                        <div class="bottom">
                          <button type="submit" class="button">
                            <span>Create</span>
                            <img src={"/images/icons/arrow-right.svg"} alt="" />
                          </button>
                        </div>
                      </form>
                    )}
                    {formId === 'progress' && (
                      <div className="progress-container">
                        <div className="video-links-container">
                          <h2>Processing Videos...</h2>
                          <ul>
                            {videoLinks.map((link, index) => (
                              <li key={index}><a href={link.link} target="_blank" rel="noopener noreferrer">{link.name}</a></li>
                            ))}
                          </ul>
                        </div>
                        <button className="cancel-button" onClick={handleGoBack}>Cancel</button>
                      </div>
                    )}
                    {formId === 'completeScreen' && (
                      <div className="progress-container">
                        <div className="video-links-container">
                          <h2>Processing Complete</h2>
                          <ul>
                            {videoLinks.map((video, index) => (
                              <li key={index}>
                                <a href={video.link} download>{video.name}</a>
                              </li>
                            ))}
                          </ul>
                        </div>
                        <button className="go-back-button" onClick={handleGoBack}>Go Back</button>
                        <button className="delete-button" onClick={handleDelete}>Delete Temporary Files</button>
                        <button className="download-all-button" onClick={handleDownloadAll}>Download All</button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div class="column second">
                <div class="row_preview">
                  <div class="previw_title">Hook Preview</div>
                  <div class="image_previw secondary">
                    <div class="wrapped">
                      <div class="sticky"
                        style={
                          {
                            backgroundColor: topBoxColor,
                            color: textColor
                          }
                        }
                      >
                        This Is How Your Hook Text Will Look Like On The Video
                      </div>
                      <div class="sticky_content">
                        your hooks content will go here
                      </div>
                    </div>
                    <img src="https://placehold.co/716x756/D9D9D9/D9D9D9" alt="" />
                  </div>
                </div>
              </div>
            </div>
            <div class="card_tutorial">
              <div class="previw_title secondary">tutorial</div>
              <div class="image_previw">
                <img src="https://placehold.co/716x600/D9D9D9/D9D9D9" alt="" />
              </div>
            </div>
          </div>
        </div>

      </div>

      <div class="footer">
        <div class="container">
          <div class="holder">
            <div class="column">
              <div class="wrapped">
                <div class="logo">
                  <a href="#">
                    <img src={"/images/logo-white.svg"} alt="" />
                  </a>
                </div>
                <div class="footer_description">
                  Every Facebook advertiser knows the power of a great video hook. Now, with HooksMaster.io, you can create winning hooks in minutes, without the hassle or expense of hiring video editors.
                </div>
                <ul class="social_list">
                  <li class="item">
                    <a href="#">
                      <img src={"/images/icons/fb.svg"} alt="" />
                    </a>
                  </li>
                  <li class="item">
                    <a href="#">
                      <img src={"/images/icons/twitter.svg"} alt="" />
                    </a>
                  </li>
                  <li class="item">
                    <a href="#">
                      <img src={"/images/icons/ln.svg"} alt="" />
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="column secondary">
              <div class="group">
                <div class="list_group">
                  <h3 class="title">Company</h3>
                  <ul class="list">
                    <li class="item">
                      <a href="#">Home</a>
                    </li>
                    <li class="item">
                      <a href="#">Portfolio</a>
                    </li>
                    <li class="item">
                      <a href="#">Pricing</a>
                    </li>
                  </ul>
                </div>
                <div class="list_group">
                  <h3 class="title">Help</h3>
                  <ul class="list">
                    <li class="item">
                      <a href="#">Contact us</a>
                    </li>
                    <li class="item">
                      <a href="#">About us</a>
                    </li>
                    <li class="item">
                      <a href="#">Terms &amp; condition</a>
                    </li>
                    <li class="item">
                      <a href="#">Privacy policy</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default Main;
