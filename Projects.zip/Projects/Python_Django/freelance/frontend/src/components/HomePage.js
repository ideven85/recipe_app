import React from "react";
import { useNavigate } from "react-router-dom";
import "./Main.css";

const HomePage = () => {

    const navigate = useNavigate();

    const handleLoginClick = () => {
        navigate("/form");
    };

    return (
        <div class="wrapper">
            <div class="header">
                <div class="container">
                    <div class="holder">
                        <div class="logo">
                            <a href="#">
                                <img src="/images/logo.svg" alt="" />
                            </a>
                        </div>
                        <div class="panel_header" data-attr-content>
                            <ul class="navigation">
                                <li class="item">
                                    <a href="#">Home</a>
                                </li>
                                <li class="item">
                                    <a href="#">Benefits</a>
                                </li>
                                <li class="item">
                                    <a href="#">About</a>
                                </li>
                                <li class="item">
                                    <a href="#">Contact</a>
                                </li>
                                <li class="item">
                                    <a href="#">Portfolio</a>
                                </li>
                            </ul>
                            <div class="auth">
                                <div class="col">
                                    <button type="button" class="button" onClick={handleLoginClick}>
                                        Login
                                    </button>
                                </div>
                                <div class="col">
                                    <button type="button" class="button secondary">
                                        Get started
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="hamburger btn_js"></button>
                    </div>
                </div>
            </div>
            <div class="main">
                <div class="section_general">
                    <div class="container">
                        <div class="columns">
                            <div class="column">
                                <div class="heading">
                                    <h1 class="title">Create <span class="marker">High-Converting</span> Video Hooks Effortlessly </h1>
                                    <div class="description">Every Facebook advertiser knows the power of a great video hook. Now, with HooksMaster.io, you can create winning hooks in minutes, without the hassle or expense of hiring video editors.</div>
                                </div>
                                <div class="group_button">
                                    <button type="button" class="button">
                                        <span>Get Started Now</span>
                                        <img src="/images/icons/arrow-right.svg" alt="" />
                                    </button>
                                </div>
                            </div>
                            <div class="column secondary">
                                <div class="video_poster">
                                    <div class="holder">
                                        <div class="wrap">
                                            <img src="https://placehold.co/530x530/D9D9D9/000" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section_works">
                    <div class="mask"></div>
                    <div class="container">
                        <div class="holder">
                            <div class="col">
                                <div class="wrapped">
                                    <h2 class="title">how it works</h2>
                                    <p>It's that simple. With HooksMaster.io, you can test hooks rapidly, find winning ads faster, and skyrocket your Facebook ad ROI.</p>
                                </div>
                            </div>
                            <div class="col">
                                <div class="cards_text">
                                    <div class="item">
                                        <div class="card">
                                            <div class="wrap">
                                                <h3 class="card_title">Prepare Your Hooks:</h3>
                                                <p>Type up your hooks in a CSV file.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="card">
                                            <div class="wrap">
                                                <h3 class="card_title">Select Video Clips:</h3>
                                                <p>Choose the video clips you want to include.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="card">
                                            <div class="wrap">
                                                <h3 class="card_title">Generate Hooks:</h3>
                                                <p>Click play and get brand new hooks instantly.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section">
                    <div class="container">
                        <div class="headline">
                            <h2 class="title">Why HooksMaster.io?</h2>
                        </div>
                        <div class="cards">
                            <div class="card_group">
                                <div class="item">
                                    <a href="#" class="card">
                                        <div class="image">
                                            <img src="/images/image01.svg" alt="" />
                                        </div>
                                        <div class="card_description">
                                            Save time and money compared to hiring video editors
                                        </div>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#" class="card">
                                        <div class="image">
                                            <img src="/images/image02.svg" alt="" />
                                        </div>
                                        <div class="card_description">
                                            Test hooks quickly to find winning ads faster
                                        </div>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#" class="card">
                                        <div class="image">
                                            <img src="/images/image03.svg" alt="" />
                                        </div>
                                        <div class="card_description">
                                            Intuitive interface - no technical skills required
                                        </div>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#" class="card">
                                        <div class="image">
                                            <img src="/images/image04.svg" alt="" />
                                        </div>
                                        <div class="card_description">
                                            Affordable pricing - hooks for less than £3 each
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section primary">
                    <div class="container">
                        <div class="headline">
                            <h2 class="title">Hooks Portfolio</h2>
                            <div class="description">Explore our gallery of successful hooks created by businesses just like yours.</div>
                        </div>
                        <div class="thumbs">
                            <div class="thumb">
                                <a href="#" class="wrap_media">
                                    <video src="video/example1.mp4" controls></video>
                                </a>
                            </div>
                            <div class="thumb">
                                <a href="#" class="wrap_media">
                                    <video src="video/example2.mp4" controls></video>
                                </a>
                            </div>
                            <div class="thumb">
                                <a href="#" class="wrap_media">
                                    <video src="video/example3.mp4" controls></video>
                                </a>
                            </div>
                            <div class="thumb">
                                <a href="#" class="wrap_media">
                                    <video src="video/example4.mp4" controls></video>
                                </a>
                            </div>
                            <div class="thumb">
                                <a href="#" class="wrap_media">
                                    <video src="video/example5.mp4" controls></video>
                                </a>
                            </div>
                            <div class="thumb">
                                <a href="#" class="wrap_media">
                                    <video src="video/example6.mp4" controls></video>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section">
                    <div class="container">
                        <div class="headline">
                            <h2 class="title">what we have done</h2>
                            <div class="description">Discover how businesses like yours are using HooksMaster.io to revolutionize their Facebook advertising:</div>
                        </div>
                        <div class="float_description">
                            <div class="col second">
                                <div class="box">
                                    <img src="/images/graph01.jpeg" alt="" />
                                </div>
                            </div>
                            <div class="col">
                                <div class="wrap align_left">
                                    <h3 class="title">E-commerce Brand Boosts Sales by 150%</h3>
                                    <p>XYZ Clothing used HooksMaster.io to create a series of engaging video hooks that showcased their products in action. By rapidly testing different hooks, they identified top-performing ads that drove a 150% increase in sales within three months.</p>
                                </div>
                            </div>
                        </div>
                        <div class="float_description">
                            <div class="col">
                                <div class="wrap">
                                    <h3 class="title">SaaS Startup Triples Lead Generation</h3>
                                    <p>ABC Software leveraged HooksMaster.io to create compelling video hooks that highlighted their platform's key features and benefits. The resulting ads attracted high-quality leads, tripling their lead generation rate and reducing customer acquisition costs by 30%.</p>
                                </div>
                            </div>
                            <div class="col second">
                                <div class="box">
                                    <img src="/images/graph02.jpeg" alt="" />
                                </div>
                            </div>
                        </div>
                        <div class="float_description">
                            <div class="col second">
                                <div class="box">
                                    <img src="/images/graph03.jpeg" alt="" />
                                </div>
                            </div>
                            <div class="col">
                                <div class="wrap align_left">
                                    <h3 class="title">Local Service Provider Dominates Market</h3>
                                    <p>123 Plumbing used HooksMaster.io to create video hooks that emphasized their expertise, reliability, and exceptional customer service. By consistently testing and optimizing their hooks, they became the go-to plumbing service in their area, increasing market share by 45% within a year.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section primary">
                    <div class="container">
                        <div class="headline">
                            <h2 class="title mw-50">Choose a plan that suits for your business</h2>
                        </div>
                        <div class="choose_list">
                            <div class="item">
                                <div class="card">
                                    <div class="sup">Starter</div>
                                    <div class="price">
                                        <span>$97</span> /month
                                    </div>
                                    <div class="hook">
                                        $1.94/hook
                                    </div>
                                    <div class="total">
                                        50 Hooks monthly
                                    </div>
                                    <button type="button" class="button">
                                        <span>Get Started</span>
                                        <img src="/images/icons/arrow-right.svg" alt="" />
                                    </button>
                                </div>
                            </div>
                            <div class="item">
                                <div class="card secondary">
                                    <div class="sticky">Most popular!</div>
                                    <div class="sup">Pro</div>
                                    <div class="price">
                                        <span>$197</span> /month
                                    </div>
                                    <div class="hook">
                                        $1.64/hook
                                    </div>
                                    <div class="total">
                                        120 Hooks monthly
                                    </div>
                                    <button type="button" class="button">
                                        <span>Get Started</span>
                                        <img src="/images/icons/arrow-right.svg" alt="" />
                                    </button>
                                </div>
                            </div>
                            <div class="item">
                                <div class="card">
                                    <div class="sup">Exclusive</div>
                                    <div class="price">
                                        <span>$497</span> /month
                                    </div>
                                    <div class="hook">
                                        $0.99/hook
                                    </div>
                                    <div class="total">
                                        500 Hooks monthly
                                    </div>
                                    <button type="button" class="button">
                                        <span>Get Started</span>
                                        <img src="/images/icons/arrow-right.svg" alt="" />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section">
                    <div class="container">
                        <div class="floating_text">
                            <div class="col second">
                                <h3 class="title">Who we are</h3>
                            </div>
                            <div class="col">
                                <p>At HooksMaster.io, we're passionate about helping businesses succeed with Facebook advertising. Our team of experienced marketers and software developers came together to create a tool that simplifies the process of creating high-converting video hooks. We understand the challenges advertisers face and are committed to providing a solution that saves time, money, and effort while delivering outstanding results.</p>
                            </div>
                        </div>
                        <div class="floating_text">
                            <div class="col second">
                                <h3 class="title">Our mission</h3>
                            </div>
                            <div class="col">
                                <p>Our mission is to empower advertisers of all sizes with the tools they need to create compelling video ads that drive engagement, conversions, and revenue. With HooksMaster.io, we're making it easier than ever to optimize your Facebook ad performance and achieve your marketing goals.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section primary">
                    <div class="container">
                        <div class="form_columns">
                            <div class="column">
                                <div class="contact_text">
                                    <div class="row">
                                        <div class="headline">
                                            <h2 class="title">Let’s get in touch</h2>
                                        </div>
                                        <p>We're here to help! If you have any questions, concerns, or feedback about HooksMaster.io, please don't hesitate to reach out to our friendly support team.</p>
                                    </div>
                                    <div class="row">
                                        <div class="wrap">
                                            <p><span class="mark">Email</span></p>
                                            <p><a href="mailto:support@hooksmaster.io">support@hooksmaster.io</a></p>
                                        </div>
                                        <p>We strive to respond to all inquiries within 24 hours during business days. For technical support, please provide as much detail as possible about the issue you're experiencing, and our team will work diligently to resolve it.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="column">
                                <div class="form_field">
                                    <form action="#">
                                        <div class="wrap">
                                            <div class="row">
                                                <label class="label">
                                                    <div class="field">full name</div>
                                                    <input type="text" class="input" placeholder="Enter your full name" />
                                                </label>
                                            </div>
                                            <div class="row">
                                                <label class="label">
                                                    <div class="field">Enter your full name</div>
                                                    <input type="email" class="input" placeholder="Enter your Email address" />
                                                </label>
                                            </div>
                                            <div class="row">
                                                <label class="label">
                                                    <div class="field">Write your message</div>
                                                    <textarea class="textarea" name="message" cols="30" rows="10" placeholder="write us your question here..."></textarea>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="group_button">
                                            <button type="button" class="button">
                                                <span>Send message</span>
                                                <img src="/images/icons/arrow-right.svg" alt="" />
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer">
                <div class="container">
                    <div class="holder">
                        <div class="column">
                            <div class="wrapped">
                                <div class="logo">
                                    <a href="#">
                                        <img src="/images/logo-white.svg" alt="" />
                                    </a>
                                </div>
                                <div class="footer_description">
                                    Every Facebook advertiser knows the power of a great video hook. Now, with HooksMaster.io, you can create winning hooks in minutes, without the hassle or expense of hiring video editors.
                                </div>
                                <ul class="social_list">
                                    <li class="item">
                                        <a href="#">
                                            <img src="/images/icons/fb.svg" alt="" />
                                        </a>
                                    </li>
                                    <li class="item">
                                        <a href="#">
                                            <img src="/images/icons/twitter.svg" alt="" />
                                        </a>
                                    </li>
                                    <li class="item">
                                        <a href="#">
                                            <img src="/images/icons/ln.svg" alt="" />
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="column secondary">
                            <div class="group">
                                <div class="list_group">
                                    <h3 class="title">Company</h3>
                                    <ul class="list">
                                        <li class="item">
                                            <a href="#">Home</a>
                                        </li>
                                        <li class="item">
                                            <a href="#">Portfolio</a>
                                        </li>
                                        <li class="item">
                                            <a href="#">Pricing</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="list_group">
                                    <h3 class="title">Help</h3>
                                    <ul class="list">
                                        <li class="item">
                                            <a href="#">Contact us</a>
                                        </li>
                                        <li class="item">
                                            <a href="#">About us</a>
                                        </li>
                                        <li class="item">
                                            <a href="#">Terms &amp; condition</a>
                                        </li>
                                        <li class="item">
                                            <a href="#">Privacy policy</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default HomePage;
